# `dwd_pub_xop_tls_package_df`

- 层级：`dwd`
- 本地表描述：自增id
- 主题标签：other
- 数据粒度：需结合实时 schema 与业务口径确认
- 分区字段：无
- 推荐项目：`dmp_ads`（bi/ads）或 `dmp_cdm`（dwd/dim）

## 关键字段

`id`、`order_id`、`customer_id`

## 字段

| 字段 | 类型 | 说明 | 来源 |
|---|---|---|---|
| `id` | `BIGINT` | 自增id | ddl |
| `order_id` | `BIGINT` | 订单ID | ddl |
| `customer_id` | `BIGINT` | 客户ID | ddl |
| `name` | `STRING` | 资源包名称 | ddl |
| `period` | `INT` | 时效，计费周期（天） | ddl |
| `total_qty` | `INT` | 总量,次数包：调用总次数，设备包：设备总数 | ddl |
| `total_price` | `DECIMAL(14,4` | 未提供字段注释 | ddl |

## ETL 与查询提示

- 写入方式：OVERWRITE
- 上游表：`ods.ods_pub_xop_xop2_tbl_package`

## 使用边界

- 本文件是基于本地 DDL/DML 的辅助元数据，不替代 MaxCompute 实时 schema。
- 执行 SQL 前使用 `mcp__maxcompute__get_table_schema` 核对字段、类型和分区。
- 查询分区表必须在 WHERE 中添加分区过滤，避免全表扫描。

## 数据质量提示

- 字段 total_price 缺少注释
- 未匹配到 INSERT SQL，来源与指标逻辑待补充
